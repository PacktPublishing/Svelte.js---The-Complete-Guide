<script>
  import Cart from "./Cart/Cart.svelte";
  import Products from "./Products/Products.svelte";
</script>

<Cart />
<Products />
