<script>
    export let title;
    export let id;
</script>

<h1>{title}</h1>
<button>Add to Cart</button>