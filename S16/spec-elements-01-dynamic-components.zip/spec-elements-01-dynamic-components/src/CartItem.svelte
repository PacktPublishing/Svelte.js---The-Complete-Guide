<script>
    export let title;
    export let id;
</script>

<h1>{title}</h1>
<button>Remove from Cart</button>