<script>
    export let val;
</script>

<input type="text" bind:value={val}>