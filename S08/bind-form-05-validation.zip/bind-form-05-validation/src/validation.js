export function isValidEmail(val) {
    return val.includes('@');
}