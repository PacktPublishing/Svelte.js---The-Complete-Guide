<script>
  import Header from "./UI/Header.svelte";
</script>

<Header />
