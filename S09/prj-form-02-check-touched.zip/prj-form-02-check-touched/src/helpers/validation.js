export function isEmpty(val) {
  return val.trim().length === 0;
}
